package entidades;

import facciones.Faccion;
import jugador.Jugador;
import otros.Dinero;
import otros.Posicion;
import otros.Vida;
import tablero.*;

public abstract class Entidad implements PuedeSerHerida, PuedeUsarHabilidad {
    private Vida vida;
    //private Faccion faccion;
    private Dinero costo;
    private Posicion posicion;
    private Jugador propietario;

    public Entidad(int vida, int costo) {
        this.vida = new Vida(vida);
        this.costo = new Dinero(costo);
    }

    public Dinero getCosto() {
        return costo;
    }


    public void disminuirVida(double cantidad, Tablero tablero) {
        vida.disminuir(cantidad);
        if(!vida.fallecio()) return;
        Casillero casillero = tablero.obtenerCasillero(posicion);
        casillero.remplazatePorVacio(tablero);
    }


    public Posicion getPosicion() {
        return posicion;
    }

    /*public void setFaccion(Faccion faccion) {
        this.faccion = faccion;
    }*/

    public void setPosicion(Posicion posicion) {
        this.posicion = posicion;
    }

    public abstract void colocarEnVacioAzul(VacioAzul vacioAzul, Tablero tablero);

    public abstract void colocarEnVacioRojo(VacioRojo vacioRojo, Tablero tablero);

    protected abstract void infligirCuracionEnEntidadAzul(double power, Tablero tablero, Entidad entidad);

    protected abstract void infligirCuracionEnEntidadRoja(double power, Tablero tablero, Entidad entidad);

    protected void aumentarVida(double curacion){
        vida.aumentar(curacion);
    }

    protected abstract void daniarEntidadAzul(double power, Tablero tablero, Entidad entidad);

    protected abstract void daniarEntidadRoja(double power, Tablero tablero, Entidad entidad);

    public abstract void guardateEnOcupado(Ocupado ocupado);
}

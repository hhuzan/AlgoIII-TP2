package facciones;

public class Rojo implements Faccion {
}

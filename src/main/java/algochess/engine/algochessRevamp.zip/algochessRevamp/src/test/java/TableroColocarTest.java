import entidades.*;
import facciones.Azul;
import facciones.Faccion;
import facciones.Rojo;
import jugador.Jugador;
import jugador.JugadorAzul;
import jugador.JugadorRojo;
import org.junit.Test;
import otros.Posicion;
import tablero.OcupadoAzul;
import tablero.Tablero;
import tablero.Vacio;
import tablero.VacioAzul;

import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertSame;

public class TableroColocarTest {

    @Test
    public void test00ConstructorTableroNoDevuelveNull() {
        Tablero tablero = new Tablero();
        assertNotNull(tablero);
    }


    @Test
    public void test01AgregoSoldadoEnTablero() {

        /*Jugador azul coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new SoldadoAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test02AgregoSoldadoEnTablero() {
        /*Jugador rojo coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new SoldadoAzul();
        Jugador jugadorRojo = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugadorRojo);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
    }

    @Test
    public void test03AgregoCuranderoEnTablero(){
        /*Jugador azul coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CuranderoAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test04AgregoCuranderoEnTablero() {
        /*Jugador rojo coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CuranderoAzul();
        Jugador jugador = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
    }

    @Test
    public void test05AgregoJineteEnTablero(){
        /*Jugador azul coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new JineteAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test06AgregoJineteEnTablero() {
        /*Jugador rojo coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new JineteAzul();
        Jugador jugador = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
    }

    @Test
    public void test07AgregoCatapultaEnTablero(){
        /*Jugador azul coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CatapultaAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test08AgregoCatapultaEnTablero() {
        /*Jugador rojo coloca pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CatapultaAzul();
        Jugador jugador = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        tablero.colocarEntidad(entidad, posicion,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
    }

}

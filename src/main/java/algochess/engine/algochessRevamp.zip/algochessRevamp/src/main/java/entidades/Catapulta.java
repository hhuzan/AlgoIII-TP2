package entidades;

import armas.ArmaAtaca;
import armas.Roca;
import tablero.Casillero;
import tablero.Ocupado;
import tablero.Tablero;

import static otros.Constantes.CATAPULTA_COSTO;
import static otros.Constantes.CATAPULTA_VIDA;

public abstract class Catapulta extends Entidad {
    private ArmaAtaca arma;
    public Catapulta() {
        super(CATAPULTA_VIDA, CATAPULTA_COSTO);
        arma = new Roca();
    }

    public ArmaAtaca getArma() {
        return arma;
    }

    @Override
    public void guardateEnOcupado(Ocupado ocupado) {
        ocupado.setPuedeSerHerida(this);
        ocupado.setPuedeUsarHabilidad(this);
    }
}

package otros;

public class Dinero {
    private int monto;

    public Dinero(int monto_) {
        monto = monto_;
    }

    public Dinero clonar(){
        return new Dinero(this.monto);
    }

    public void sumarDinero(Dinero suma){
       this.monto = this.monto + suma.monto;
    }

    public Dinero restarDinero(Dinero costo) {
        int nuevo_monto = monto - costo.monto;
        if (nuevo_monto < 0) {
            return new Dinero(0);
        }
        monto = nuevo_monto;
        return new Dinero(costo.monto);
    }

    public boolean sonIguales(Dinero dinero) {
        return monto == dinero.monto;
    }
}

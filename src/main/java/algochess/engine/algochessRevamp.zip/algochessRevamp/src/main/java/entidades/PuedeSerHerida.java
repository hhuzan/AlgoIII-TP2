package entidades;

import tablero.Tablero;

public interface PuedeSerHerida {
    /*Metodo llamado desde el casillero, la entidad decide cuanto daño hacerse*/
    void infligirDanioDesdeCasilleroAzul(double power, Entidad emisor, Tablero tablero);

    void infligirDanioDesdeCasilleroRojo(double power, Entidad emisor, Tablero tablero);


}

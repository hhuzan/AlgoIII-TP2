package armas;

import armas.rangos.Corto;
import entidades.Entidad;
import otros.Posicion;
import tablero.Casillero;
import tablero.Tablero;

import static otros.Constantes.VACULO_PODER;

public class Vaculo extends Arma implements ArmaCura {
    public Vaculo() {
        super(VACULO_PODER, new Corto());
    }

    @Override
    public void curar(Posicion origen, Casillero receptor, Tablero tablero, Entidad emisor) {
        if(!getRango().casilleroEstaEnRango(receptor,origen)) return;
        receptor.infligirCuracion(getPower(),emisor,tablero);

    }
}

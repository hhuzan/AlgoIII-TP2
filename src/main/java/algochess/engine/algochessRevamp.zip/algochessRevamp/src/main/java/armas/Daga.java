package armas;

import armas.rangos.Corto;
import entidades.Entidad;
import otros.Posicion;
import tablero.Casillero;
import tablero.Tablero;

import static otros.Constantes.DAGA_PODER;

public class Daga extends Arma implements ArmaAtaca {

    public Daga() {
        super(DAGA_PODER, new Corto());
    }


    @Override
    public void atacar(Posicion posicion, Casillero receptor, Tablero tablero, Entidad emisor) {
        if(!getRango().casilleroEstaEnRango(receptor,posicion)) return;
        receptor.infligirDanio(getPower(),emisor,tablero);

    }
}

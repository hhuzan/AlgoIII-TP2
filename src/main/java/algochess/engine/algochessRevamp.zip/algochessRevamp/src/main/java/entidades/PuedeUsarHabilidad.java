package entidades;

import facciones.Azul;
import facciones.Faccion;
import jugador.Jugador;
import tablero.Casillero;
import tablero.Tablero;

public interface PuedeUsarHabilidad {
    void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador);
    void ejecutaHabilidad(Casillero receptor, Tablero tablero);

}

import entidades.*;
import facciones.Azul;
import facciones.Faccion;
import facciones.Rojo;
import jugador.Jugador;
import jugador.JugadorAzul;
import jugador.JugadorRojo;
import org.junit.Test;
import otros.Posicion;
import tablero.OcupadoAzul;
import tablero.Tablero;
import tablero.Vacio;
import tablero.VacioAzul;

import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertSame;

public class TableroMoverTest {

    @Test
    public void test00ConstructorTableroNoDevuelveNull() {
        Tablero tablero = new Tablero();
        assertNotNull(tablero);
    }


    @Test
    public void test01MuevoSoldadoEnTablero() {

        /*Jugador azul mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new SoldadoAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugador);
        tablero.moverEntidad(posicion,posicion1,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test02MuevoSoldadoFallaEnTablero() {
        /*Jugador rojo mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new SoldadoAzul();
        Jugador jugadorA = new JugadorAzul();
        Jugador jugadorR = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugadorA);
        tablero.moverEntidad(posicion,posicion1,jugadorR);


        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), VacioAzul.class);
    }

    @Test
    public void test03MuevoJineteEnTablero() {

        /*Jugador azul mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new JineteAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugador);
        tablero.moverEntidad(posicion,posicion1,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test04MuevoJineteFallaEnTablero() {
        /*Jugador rojo mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new JineteAzul();
        Jugador jugadorA = new JugadorAzul();
        Jugador jugadorR = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugadorA);
        tablero.moverEntidad(posicion,posicion1,jugadorR);


        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), VacioAzul.class);
    }


    @Test
    public void test05MuevoCuranderoEnTablero() {
        /*Jugador azul mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CuranderoAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugador);
        tablero.moverEntidad(posicion,posicion1,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), VacioAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), OcupadoAzul.class);
    }

    @Test
    public void test06MuevoCuranderoFallaEnTablero() {
        /*Jugador rojo mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CuranderoAzul();

        Jugador jugadorA = new JugadorAzul();
        Jugador jugadorR = new JugadorRojo();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugadorA);
        tablero.moverEntidad(posicion,posicion1,jugadorR);


        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), VacioAzul.class);
    }

    @Test
    public void test07MuevoCatapultaFallaEnTablero() {
        /*Jugador azul mueve pieza azul en casillero azul*/
        Tablero tablero = new Tablero();
        Entidad entidad = new CatapultaAzul();
        Jugador jugador = new JugadorAzul();

        Posicion posicion = new Posicion(5, 6);
        Posicion posicion1 = new Posicion(5,7);

        tablero.colocarEntidad(entidad, posicion,jugador);
        tablero.moverEntidad(posicion,posicion1,jugador);

        assertSame(tablero.obtenerCasillero(posicion).getClass(), OcupadoAzul.class);
        assertSame(tablero.obtenerCasillero(posicion1).getClass(), VacioAzul.class);
    }

}

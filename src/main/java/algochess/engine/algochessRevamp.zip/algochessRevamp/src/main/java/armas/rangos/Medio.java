package armas.rangos;

import static otros.Constantes.RANGO_MEDIO_MAXIMO;
import static otros.Constantes.RANGO_MEDIO_MINIMO;

public class Medio extends Rango {

    public Medio() {
        super(RANGO_MEDIO_MINIMO, RANGO_MEDIO_MAXIMO);
    }

}

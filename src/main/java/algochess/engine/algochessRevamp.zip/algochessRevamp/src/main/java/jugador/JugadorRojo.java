package jugador;

import entidades.Entidad;
import entidades.PuedeUsarHabilidad;
import facciones.Rojo;
import tablero.Casillero;
import tablero.Tablero;
import tablero.VacioAzul;
import tablero.VacioRojo;

public class JugadorRojo extends Jugador {

    public JugadorRojo(){
        super();
        setFaccion(new Rojo());
    }



    @Override
    public void mueveEntidadAzul(Casillero origen, Casillero destino, Tablero tablero, Entidad entidad) {
        //No mueve entidades azules
    }

    @Override
    public void mueveEntidadRoja(Casillero origen, Casillero destino, Tablero tablero, Entidad entidad) {
        destino.recibirEntidad(origen, entidad,tablero);

    }

    @Override
    public void usaHabilidadEntidadAzul(Casillero receptor, Tablero tablero, PuedeUsarHabilidad entidad) {
        //No usa habilidad de azules
    }

    @Override
    public void usaHabilidadEntidadRojo(Casillero receptor, Tablero tablero, PuedeUsarHabilidad entidad) {
        entidad.ejecutaHabilidad(receptor,tablero);
    }

    @Override
    public void colocaEntidadEnVacioAzul(Entidad entidad, VacioAzul vacioAzul, Tablero tablero) {
        //NO HACE NADA
    }

    @Override
    public void colocaEntidadEnVacioRojo(Entidad entidad, VacioRojo vacioRojo, Tablero tablero) {
        entidad.colocarEnVacioRojo(vacioRojo,tablero);

    }
}

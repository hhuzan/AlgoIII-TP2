package tablero;

import entidades.Entidad;
import facciones.Rojo;
import jugador.Jugador;
import otros.Posicion;

public class VacioRojo extends Vacio {

    public VacioRojo(Posicion posicion) {
        super(posicion);
    }

    public void remplazatePorOcupadoRojo(Tablero tablero, Entidad entidad){
        tablero.colocarCasillero(new OcupadoRojo(getPosicion(),entidad),getPosicion());
    }

    @Override
    public void colocarEntidad(Entidad entidad, Tablero tablero, Jugador jugador) {
        jugador.colocaEntidadEnVacioRojo(entidad, this,tablero);
    }

    @Override
    public void recibirEntidad(Casillero origen, Entidad entidad, Tablero tablero) {
        origen.remplazatePorVacio(tablero);
        remplazatePorOcupadoRojo(tablero,entidad);
    }
}

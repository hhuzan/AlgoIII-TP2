package entidades;

import jugador.Jugador;
import tablero.*;

public class CatapultaAzul extends Catapulta {

    @Override
    public void colocarEnVacioAzul(VacioAzul vacioAzul, Tablero tablero) {
        /*La entidad sabe que es azul, así que le dirá al casillero vacio azul que se remplace por uno ocupado azul*/
        vacioAzul.remplazatePorOcupadoAzul(tablero,this);
    }

    @Override
    public void colocarEnVacioRojo(VacioRojo vacioRojo, Tablero tablero) {
        //No puede colocarse en vacio rojo
    }

    @Override
    protected void infligirCuracionEnEntidadAzul(double power, Tablero tablero, Entidad entidad) {
        //No puede curar
    }

    @Override
    protected void infligirCuracionEnEntidadRoja(double power, Tablero tablero, Entidad entidad) {
        //No puede curar
    }

    protected void aumentarVida(double curacion){
        //no puede aumentarse vida
    }

    @Override
    protected void daniarEntidadAzul(double power, Tablero tablero, Entidad entidad) {
        entidad.disminuirVida(power,tablero);
    }

    @Override
    protected void daniarEntidadRoja(double power, Tablero tablero, Entidad entidad) {
        entidad.disminuirVida(power,tablero);
    }




    /*El jugador decide si puede usar la pieza o no*/
    @Override
    public void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador) {
        jugador.usaHabilidadEntidadAzul(receptor,tablero,this);
    }

    /*El jugador ejecuta este método en la pieza*/
    @Override
    public void ejecutaHabilidad(Casillero receptor, Tablero tablero) {
        getArma().atacar(getPosicion(),receptor,tablero,this);
    }

    @Override
    public void infligirDanioDesdeCasilleroAzul(double power, Entidad emisor, Tablero tablero) {
        emisor.daniarEntidadAzul(power,tablero,this);
    }

    @Override
    public void infligirDanioDesdeCasilleroRojo(double power, Entidad emisor, Tablero tablero) {
        emisor.daniarEntidadAzul(power+power*.05,tablero,this);
    }
}

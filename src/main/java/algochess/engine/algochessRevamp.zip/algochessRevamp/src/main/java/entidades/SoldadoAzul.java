package entidades;

import armas.ArmaAtaca;
import jugador.Jugador;
import tablero.Casillero;
import tablero.Tablero;
import tablero.VacioAzul;
import tablero.VacioRojo;

public class SoldadoAzul extends Soldado{
    private ArmaAtaca arma;

    @Override
    public void colocarEnVacioAzul(VacioAzul vacioAzul, Tablero tablero) {
        /*La entidad sabe que es azul, así que le dirá al casillero vacio azul que se remplace por uno ocupado azul*/
        vacioAzul.remplazatePorOcupadoAzul(tablero,this);
    }

    @Override
    public void colocarEnVacioRojo(VacioRojo vacioRojo, Tablero tablero) {
        //No puede colocarse en vacio rojo
    }

    @Override
    protected void infligirCuracionEnEntidadAzul(double power, Tablero tablero, Entidad entidad) {
        //No puede curar
    }

    @Override
    protected void infligirCuracionEnEntidadRoja(double power, Tablero tablero, Entidad entidad) {
        //No puede curar
    }

    @Override
    protected void daniarEntidadAzul(double power, Tablero tablero, Entidad entidad) {
        //No daño entidades azules
    }

    @Override
    protected void daniarEntidadRoja(double power, Tablero tablero, Entidad entidad) {
        entidad.disminuirVida(power,tablero);
    }

    @Override
    public void mover(Casillero origen, Casillero destino, Tablero tablero, Jugador jugador) {
        jugador.mueveEntidadAzul(origen,destino,tablero,this);
    }


    @Override
    public void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador) {
        jugador.usaHabilidadEntidadAzul(receptor,tablero,this);
    }

    @Override
    public void ejecutaHabilidad(Casillero receptor, Tablero tablero) {
        getArma().atacar(getPosicion(),receptor,tablero,this);
    }

    @Override
    public void infligirDanioDesdeCasilleroAzul(double power, Entidad emisor, Tablero tablero) {
        emisor.daniarEntidadAzul(power,tablero,this);
    }

    @Override
    public void infligirDanioDesdeCasilleroRojo(double power, Entidad emisor, Tablero tablero) {
        emisor.daniarEntidadAzul(power+power*.05,tablero,this);
    }

    @Override
    public void infligirCuracion(double power, Entidad emisor, Tablero tablero) {
        emisor.infligirCuracionEnEntidadAzul(power,tablero,this);
    }
}

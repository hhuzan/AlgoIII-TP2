package armas;

import armas.rangos.Rango;

abstract class Arma {
    private double power;
    private Rango rango;

    Arma(int power, Rango rango) {
        this.power = power;
        this.rango = rango;
    }

    public Rango getRango() {
        return rango;
    }

    public double getPower() {
        return power;
    }
}

package entidades;

import armas.ArmaAtaca;
import armas.Espada;
import tablero.Casillero;
import tablero.Ocupado;
import tablero.Tablero;

import static otros.Constantes.SOLDADO_COSTO;
import static otros.Constantes.SOLDADO_VIDA;

public abstract class Soldado extends Entidad implements PuedeMoverse, PuedeFormarBatallon, PuedeSerCurada{
    private ArmaAtaca arma;
    public Soldado() {
        super(SOLDADO_VIDA, SOLDADO_COSTO);
        arma = new Espada();
    }

    public ArmaAtaca getArma() {
        return arma;
    }

    @Override
    public void guardateEnOcupado(Ocupado ocupado) {
        ocupado.setPuedeMoverse(this);
        ocupado.setPuedeSerCurada(this);
        ocupado.setPuedeSerHerida(this);
        ocupado.setPuedeUsarHabilidad(this);
        ocupado.setPuedeFormarBatallon(this);
    }
}

package entidades;

import armas.ArmaAtaca;
import armas.Daga;
import tablero.Casillero;
import tablero.Ocupado;
import tablero.Tablero;

import static otros.Constantes.JINETE_COSTO;
import static otros.Constantes.JINETE_VIDA;

public abstract class Jinete extends Entidad implements PuedeMoverse, PuedeSerCurada{
    private ArmaAtaca arma;

    public Jinete() {
        super(JINETE_VIDA, JINETE_COSTO);
        arma = new Daga();
    }

    public ArmaAtaca getArma() {
        return arma;
    }

    @Override
    public void guardateEnOcupado(Ocupado ocupado) {
        ocupado.setPuedeMoverse(this);
        ocupado.setPuedeSerCurada(this);
        ocupado.setPuedeSerHerida(this);
        ocupado.setPuedeUsarHabilidad(this);
    }
}

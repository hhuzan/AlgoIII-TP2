package otros;

public class Vida {
    private double puntosdevida;

    public Vida(double vida) {
        puntosdevida = vida;
    }

    public void aumentar(double cantidad) {
        puntosdevida = puntosdevida + cantidad;
    }

    public void disminuir(double cantidad) {
        puntosdevida = puntosdevida - cantidad;
    }

    public boolean igualA(double vida) {
        return vida == puntosdevida;
    }

    public boolean fallecio() {
        return (puntosdevida <= 0);
    }
}

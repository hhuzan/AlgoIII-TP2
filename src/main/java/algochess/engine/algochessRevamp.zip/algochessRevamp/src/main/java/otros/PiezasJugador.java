package otros;

import entidades.Entidad;

public class PiezasJugador {

    public void agregar(Entidad entidad){}
}

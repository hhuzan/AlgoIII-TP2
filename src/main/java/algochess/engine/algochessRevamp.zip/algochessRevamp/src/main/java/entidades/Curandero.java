package entidades;

import armas.ArmaCura;
import armas.Vaculo;
import tablero.Casillero;
import tablero.Ocupado;
import tablero.Tablero;

import static otros.Constantes.CURANDERO_COSTO;
import static otros.Constantes.CURANDERO_VIDA;

public abstract class Curandero extends Entidad implements PuedeMoverse, PuedeSerCurada{
    private ArmaCura arma;
    public Curandero() {
        super(CURANDERO_VIDA, CURANDERO_COSTO);
        arma = new Vaculo();
    }

    public ArmaCura getArma() {
        return arma;
    }

    @Override
    public void guardateEnOcupado(Ocupado ocupado) {
        ocupado.setPuedeMoverse(this);
        ocupado.setPuedeSerCurada(this);
        ocupado.setPuedeSerHerida(this);
        ocupado.setPuedeUsarHabilidad(this);
    }
}

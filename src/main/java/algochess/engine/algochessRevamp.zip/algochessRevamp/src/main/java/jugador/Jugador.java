package jugador;

import entidades.Entidad;
import entidades.PuedeUsarHabilidad;
import facciones.Faccion;
import otros.Dinero;
import otros.PiezasJugador;
import tablero.Casillero;
import tablero.Tablero;
import tablero.VacioAzul;
import tablero.VacioRojo;
import vendedordeentidades.VendedorDeEntidades;

import static otros.Constantes.DINERO_JUGADOR;

public abstract class Jugador {
    private Faccion faccion;
    private Dinero dinero;
    private String nombre;
    private PiezasJugador piezas;

    public Jugador(){
        dinero = new Dinero(DINERO_JUGADOR);
        setNombre("");
    }

    public void setFaccion(Faccion faccion) {
        this.faccion = faccion;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void venderEntidad(Entidad entidad, VendedorDeEntidades vendedor){
        Dinero venta = vendedor.comprarEntidad(entidad);
        dinero.sumarDinero(venta);
    }

    public void comprarEntidad(Entidad entidad, VendedorDeEntidades vendedor){
        Dinero pago = dinero.restarDinero(entidad.getCosto());
        Entidad miEntidad = vendedor.venderEntidad(entidad,pago);
        piezas.agregar(miEntidad);
    }

    public abstract void mueveEntidadAzul(Casillero origen, Casillero destino, Tablero tablero, Entidad entidad);
    public abstract void mueveEntidadRoja(Casillero origen, Casillero destino, Tablero tablero, Entidad entidad);

    public abstract void usaHabilidadEntidadAzul(Casillero receptor, Tablero tablero, PuedeUsarHabilidad entidad);
    public abstract void usaHabilidadEntidadRojo(Casillero receptor, Tablero tablero, PuedeUsarHabilidad entidad);

    public abstract void colocaEntidadEnVacioAzul(Entidad entidad, VacioAzul vacioAzul, Tablero tablero);
    public abstract void colocaEntidadEnVacioRojo(Entidad entidad, VacioRojo vacioRojo, Tablero tablero);
}

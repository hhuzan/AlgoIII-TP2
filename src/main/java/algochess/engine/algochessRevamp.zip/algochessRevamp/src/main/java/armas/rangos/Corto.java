package armas.rangos;

import static otros.Constantes.RANGO_CERCANO_MAXIMO;
import static otros.Constantes.RANGO_CERCANO_MINIMO;

public class Corto extends Rango {
    public Corto() {
        super(RANGO_CERCANO_MINIMO, RANGO_CERCANO_MAXIMO);
    }
}
package armas;

import entidades.Entidad;
import facciones.Faccion;
import otros.Posicion;
import tablero.Casillero;
import tablero.Tablero;

public interface ArmaCura {
    void curar(Posicion origen, Casillero receptor, Tablero tablero, Entidad emisor);
}

package jugador;

import entidades.Entidad;
import entidades.PuedeUsarHabilidad;
import facciones.Azul;
import otros.Dinero;
import tablero.Casillero;
import tablero.Tablero;
import tablero.VacioAzul;
import tablero.VacioRojo;

import static otros.Constantes.DINERO_JUGADOR;

public class JugadorAzul extends Jugador {

    public JugadorAzul(){
        super();
        setFaccion(new Azul());
    }

    @Override
    public void mueveEntidadAzul(Casillero origen, Casillero destino, Tablero tablero, Entidad entidad) {
        //entidad.ejecutarMovimiento(origen,destino,tablero);
        destino.recibirEntidad(origen, entidad,tablero);
    }

    @Override
    public void mueveEntidadRoja(Casillero origen, Casillero destino, Tablero tablero, Entidad entidad) {
        //No mueve entidades rojas
    }

    @Override
    public void usaHabilidadEntidadAzul(Casillero receptor, Tablero tablero, PuedeUsarHabilidad entidad) {
        entidad.ejecutaHabilidad(receptor,tablero);
    }

    @Override
    public void usaHabilidadEntidadRojo(Casillero receptor, Tablero tablero, PuedeUsarHabilidad entidad) {
        //No usa habilidades de rojos
    }

    @Override
    public void colocaEntidadEnVacioAzul(Entidad entidad, VacioAzul vacioAzul, Tablero tablero) {
        entidad.colocarEnVacioAzul(vacioAzul,tablero);

    }

    @Override
    public void colocaEntidadEnVacioRojo(Entidad entidad, VacioRojo vacioRojo, Tablero tablero) {
        //NO HACE NADA
    }
}

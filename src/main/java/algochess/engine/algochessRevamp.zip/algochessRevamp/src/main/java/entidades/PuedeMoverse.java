package entidades;

import facciones.Faccion;
import jugador.Jugador;
import tablero.Casillero;
import tablero.Tablero;

public interface PuedeMoverse {
    void mover(Casillero origen, Casillero destino, Tablero tablero , Jugador jugador);
}

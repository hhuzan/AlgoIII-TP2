package entidades;

public interface PuedeFormarBatallon {
}

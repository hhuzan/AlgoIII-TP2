package entidades;

import jugador.Jugador;
import tablero.Casillero;
import tablero.Tablero;
import tablero.VacioAzul;
import tablero.VacioRojo;

public class CatapultaRoja extends Catapulta {

    @Override
    public void colocarEnVacioAzul(VacioAzul vacioAzul, Tablero tablero) {
        //No se puede colocar en vacio azul
    }

    @Override
    public void colocarEnVacioRojo(VacioRojo vacioRojo, Tablero tablero) {
        vacioRojo.remplazatePorOcupadoRojo(tablero, this);
    }

    @Override
    protected void infligirCuracionEnEntidadAzul(double power, Tablero tablero, Entidad entidad) {
        //No puede curar
    }

    @Override
    protected void infligirCuracionEnEntidadRoja(double power, Tablero tablero, Entidad entidad) {
        //No puede curar
    }

    protected void aumentarVida(double curacion){
        //no puede aumentarse vida
    }

    @Override
    protected void daniarEntidadAzul(double power, Tablero tablero, Entidad entidad) {
        entidad.disminuirVida(power,tablero);
    }

    @Override
    protected void daniarEntidadRoja(double power, Tablero tablero, Entidad entidad) {
        entidad.disminuirVida(power,tablero);
    }


    @Override
    public void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador) {
        jugador.usaHabilidadEntidadRojo(receptor,tablero,this);

    }

    @Override
    public void ejecutaHabilidad(Casillero receptor, Tablero tablero) {
        getArma().atacar(getPosicion(),receptor,tablero,this);
    }

    @Override
    public void infligirDanioDesdeCasilleroAzul(double power, Entidad emisor, Tablero tablero) {
        emisor.daniarEntidadRoja(power+power*0.05,tablero,this);
    }

    @Override
    public void infligirDanioDesdeCasilleroRojo(double power, Entidad emisor, Tablero tablero) {
        emisor.daniarEntidadRoja(power,tablero,this);
    }
}

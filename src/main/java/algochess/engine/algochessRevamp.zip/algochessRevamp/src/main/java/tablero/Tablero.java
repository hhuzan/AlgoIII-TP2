package tablero;

import entidades.Entidad;
import facciones.Azul;
import facciones.Faccion;
import facciones.Rojo;
import jugador.Jugador;
import otros.Calculadora;
import otros.Posicion;

import static otros.Constantes.MAXIMA_DISTANCIA_POR_MOVIMIENTO;
import static otros.Constantes.TAMANIO_TABLERO;

public class Tablero {
    private Casillero[][] casilleros;

    /*Funcion que determina si un movimiento es válido*/
    /*Retorna true en caso el movimiento sea válido, false en caso contrario */
    private boolean esMovimientoValido(Posicion origen, Posicion destino) {
        Calculadora calculadora = new Calculadora();
        int x1, y1, x2, y2, distancia;
        x1 = origen.getColumna();
        y1 = origen.getFila();
        x2 = destino.getColumna();
        y2 = destino.getFila();
        distancia = MAXIMA_DISTANCIA_POR_MOVIMIENTO;

        return calculadora.distanciaValidaEntreDosPosiciones(x1, y1, x2, y2, distancia, distancia);
    }

    /*Funcion arma el tablero*/
    public Tablero(){
        int tamanio = TAMANIO_TABLERO;
        casilleros = new Casillero[tamanio][tamanio];

        // Arma sector azul
        for (int fila = 0; fila < tamanio / 2; fila++) {
            for (int columna = 0; columna < tamanio; columna++) {
                casilleros[fila][columna] = new VacioAzul(new Posicion(fila, columna));
            }
        }

        // Arma sector rojo
        for (int fila = tamanio / 2; fila < tamanio; fila++) {
            for (int columna = 0; columna < tamanio; columna++) {
                casilleros[fila][columna] = new VacioRojo(new Posicion(fila, columna));
            }
        }
    }

    /*Retorna un casillero del tablero usando una posicion*/
    public Casillero obtenerCasillero(Posicion posicion){
        return casilleros[posicion.getFila()][posicion.getColumna()];
    }

    /*Coloca un casillero en la posicion indicada*/
    public void colocarCasillero(Casillero casillero, Posicion posicion){
        casilleros[posicion.getFila()][posicion.getColumna()] = casillero;
    }

    /*Coloca una entidad en un casillero con determinada posicion, usando la faccion del jugador*/
    public void colocarEntidad(Entidad entidad, Posicion posicion, Jugador jugador) {
        Casillero casillero = casilleros[posicion.getFila()][posicion.getColumna()];
        casillero.colocarEntidad(entidad, this, jugador);
    }


    /*Usa la habilidad de la entidad en posicion emisor sobre la entidad sobre posicion receptor*/
    /*La faccion es la faccion del jugador que envía la orden*/
    public void usarHabilidad(Posicion emisor, Posicion receptor, Jugador jugador) {
        Casillero casilleroEmisor = casilleros[emisor.getFila()][emisor.getColumna()];
        Casillero casilleroReceptor = casilleros[receptor.getFila()][receptor.getColumna()];
        casilleroEmisor.usarHabilidad(casilleroReceptor, this, jugador);
    }

    /*Funcion para mover entidad, la faccion es la del jugador*/
    public void moverEntidad(Posicion origen, Posicion destino, Jugador jugador){
        if(!esMovimientoValido(origen,destino)) return;

        Casillero desde = obtenerCasillero(origen);
        Casillero hacia = obtenerCasillero(destino);

        desde.moverEntidad(hacia, this, jugador);
    }

}

package tablero;

import entidades.Entidad;
import entidades.EntidadNull;
import facciones.Azul;
import facciones.Faccion;
import jugador.Jugador;
import otros.Posicion;

public class OcupadoAzul extends Ocupado {

    public OcupadoAzul(Posicion posicion, Entidad entidad ) {
        super(posicion);
        setPuedeFormarBatallon( new EntidadNull());
        setPuedeMoverse(new EntidadNull());
        setPuedeSerCurada(new EntidadNull());
        setPuedeSerHerida(new EntidadNull());
        setPuedeUsarHabilidad(new EntidadNull());

        entidad.guardateEnOcupado(this);
    }

    @Override
    public void remplazatePorVacio(Tablero tablero) {
        tablero.colocarCasillero(new VacioAzul(getPosicion()),getPosicion());
    }

    @Override
    public void infligirDanio(double power, Entidad emisor, Tablero tablero) {
        puedeSerHerida.infligirDanioDesdeCasilleroAzul(power,emisor,tablero);
    }

    @Override
    public void infligirCuracion(double power, Entidad emisor, Tablero tablero) {
        puedeSerCurada.infligirCuracion(power,emisor,tablero);
    }
}

package armas;

import entidades.Entidad;
import facciones.Faccion;
import otros.Posicion;
import tablero.Casillero;
import tablero.Tablero;

public interface ArmaAtaca {
    void atacar(Posicion posicion, Casillero receptor, Tablero tablero, Entidad emisor);
}

package tablero;

import entidades.Entidad;
import facciones.Faccion;
import jugador.Jugador;
import otros.Posicion;

public abstract class Casillero {
    private Posicion posicion;
    private Faccion faccion;

    public Casillero(Posicion posicion){
        this.posicion = posicion;
    }


    public Faccion getFaccion() {
        return faccion;
    }

    public Posicion getPosicion() {
        return posicion;
    }

    /*Métodos principales*/
    public abstract void colocarEntidad(Entidad entidad, Tablero tablero, Jugador jugador);
    public abstract void recibirEntidad(Casillero origen, Entidad entidad, Tablero tablero);
    public abstract void moverEntidad(Casillero destino, Tablero tablero, Jugador jugador);
    public abstract void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador);
    public abstract void remplazatePorVacio(Tablero tablero);

    public abstract void infligirDanio(double power, Entidad emisor, Tablero tablero);

    public abstract void infligirCuracion(double power, Entidad emisor, Tablero tablero);
}

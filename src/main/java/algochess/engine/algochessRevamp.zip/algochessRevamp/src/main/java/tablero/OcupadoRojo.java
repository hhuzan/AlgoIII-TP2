package tablero;

import entidades.Entidad;
import entidades.EntidadNull;
import facciones.Faccion;
import facciones.Rojo;
import jugador.Jugador;
import otros.Posicion;

public class OcupadoRojo extends Ocupado {

    public OcupadoRojo(Posicion posicion, Entidad entidad) {
        super(posicion);
        setPuedeFormarBatallon( new EntidadNull());
        setPuedeMoverse(new EntidadNull());
        setPuedeSerCurada(new EntidadNull());
        setPuedeSerHerida(new EntidadNull());
        setPuedeUsarHabilidad(new EntidadNull());

        entidad.guardateEnOcupado(this);
    }

    @Override
    public void remplazatePorVacio(Tablero tablero) {
        tablero.colocarCasillero(new VacioRojo(getPosicion()),getPosicion());
    }

    @Override
    public void infligirDanio(double power, Entidad emisor, Tablero tablero) {
        puedeSerHerida.infligirDanioDesdeCasilleroRojo(power,emisor,tablero);
    }

    @Override
    public void infligirCuracion(double power, Entidad emisor, Tablero tablero) {
        puedeSerCurada.infligirCuracion(power, emisor, tablero);
    }

}

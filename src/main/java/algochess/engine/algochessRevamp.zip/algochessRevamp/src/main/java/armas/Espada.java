package armas;

import armas.rangos.Corto;
import entidades.Entidad;
import otros.Posicion;
import tablero.Casillero;
import tablero.Tablero;

import static otros.Constantes.ESPADA_PODER;

public class Espada extends Arma implements ArmaAtaca {

    public Espada() {
        super(ESPADA_PODER, new Corto());
    }

    @Override
    public void atacar(Posicion posicion, Casillero receptor, Tablero tablero, Entidad emisor) {
        if(!getRango().casilleroEstaEnRango(receptor,posicion)) return;
        receptor.infligirDanio(getPower(),emisor,tablero);
    }
}

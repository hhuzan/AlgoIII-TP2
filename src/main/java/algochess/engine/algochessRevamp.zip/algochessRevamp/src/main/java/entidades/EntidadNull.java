package entidades;

import jugador.Jugador;
import tablero.Casillero;
import tablero.Tablero;

public class EntidadNull implements PuedeFormarBatallon, PuedeSerCurada,PuedeMoverse,PuedeSerHerida,PuedeUsarHabilidad {
    @Override
    public void mover(Casillero origen, Casillero destino, Tablero tablero, Jugador jugador) {
        //No hace nada
    }

    @Override
    public void infligirCuracion(double power, Entidad emisor, Tablero tablero) {
        //No hace nada
    }

    @Override
    public void infligirDanioDesdeCasilleroAzul(double power, Entidad emisor, Tablero tablero) {
        //No hace nada
    }

    @Override
    public void infligirDanioDesdeCasilleroRojo(double power, Entidad emisor, Tablero tablero) {
        //No hace nada
    }

    @Override
    public void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador) {
        //No hace nada
    }

    @Override
    public void ejecutaHabilidad(Casillero receptor, Tablero tablero) {

    }
}

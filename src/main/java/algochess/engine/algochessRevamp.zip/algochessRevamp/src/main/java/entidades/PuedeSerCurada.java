package entidades;

import tablero.Tablero;

public interface PuedeSerCurada {
    void infligirCuracion(double power, Entidad emisor, Tablero tablero);

}

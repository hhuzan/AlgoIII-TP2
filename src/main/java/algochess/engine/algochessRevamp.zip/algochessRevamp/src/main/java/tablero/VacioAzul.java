package tablero;

import entidades.Entidad;
import facciones.Azul;
import jugador.Jugador;
import otros.Posicion;

public class VacioAzul extends Vacio {

    public VacioAzul(Posicion posicion) {
        super(posicion);
    }

    public void remplazatePorOcupadoAzul(Tablero tablero, Entidad entidad){
        tablero.colocarCasillero( new OcupadoAzul(getPosicion(),entidad),getPosicion());
    }

    @Override
    public void colocarEntidad(Entidad entidad, Tablero tablero, Jugador jugador) {
        jugador.colocaEntidadEnVacioAzul(entidad, this,tablero);
    }

    @Override
    public void recibirEntidad(Casillero origen, Entidad entidad, Tablero tablero) {
        origen.remplazatePorVacio(tablero);
        remplazatePorOcupadoAzul(tablero,entidad);
    }
}

package tablero;

import entidades.*;
import facciones.Faccion;
import jugador.Jugador;
import otros.Posicion;

public abstract class Ocupado extends Casillero{
    protected PuedeUsarHabilidad puedeUsarHabilidad;
    protected PuedeFormarBatallon puedeFormarBatallon;
    protected PuedeMoverse puedeMoverse;
    protected PuedeSerHerida puedeSerHerida;
    protected PuedeSerCurada puedeSerCurada;



    public void setPuedeFormarBatallon(PuedeFormarBatallon puedeFormarBatallon) {
        this.puedeFormarBatallon = puedeFormarBatallon;
    }

    public void setPuedeMoverse(PuedeMoverse puedeMoverse) {
        this.puedeMoverse = puedeMoverse;
    }

    public void setPuedeSerCurada(PuedeSerCurada puedeSerCurada) {
        this.puedeSerCurada = puedeSerCurada;
    }

    public void setPuedeSerHerida(PuedeSerHerida puedeSerHerida) {
        this.puedeSerHerida = puedeSerHerida;
    }

    public void setPuedeUsarHabilidad(PuedeUsarHabilidad puedeUsarHabilidad) {
        this.puedeUsarHabilidad = puedeUsarHabilidad;
    }

    public Ocupado(Posicion posicion) {
        super(posicion);
    }

    public void colocarEntidad(Entidad entidad, Tablero tablero, Jugador jugador){
        //Nunca se puede colocar entidad en casillero ocupado
    }

    public void recibirEntidad(Casillero origen, Entidad entidad, Tablero tablero){
        //Nunca se puede recibir entidad en casillero ocupado
    }

    public void moverEntidad(Casillero destino, Tablero tablero, Jugador jugador) {
        puedeMoverse.mover(this, destino,tablero,jugador);
    }
    public void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador){
        puedeUsarHabilidad.usarHabilidad(receptor,tablero,jugador);
    }

}

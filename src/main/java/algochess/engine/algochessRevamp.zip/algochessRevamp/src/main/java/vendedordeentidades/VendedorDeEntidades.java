package vendedordeentidades;


import entidades.Entidad;
import otros.Dinero;

public class VendedorDeEntidades {
    public Entidad venderEntidad(Entidad entidad, Dinero pago) {
        if (entidad.getCosto().sonIguales(pago)) {
            return entidad;
        }
        return null;
    }

    public Dinero comprarEntidad(Entidad entidad){
        if(entidad == null) return new Dinero(0);
        else return entidad.getCosto().clonar();
    }
}

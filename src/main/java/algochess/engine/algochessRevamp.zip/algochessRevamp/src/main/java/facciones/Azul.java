package facciones;

public class Azul implements Faccion {
}

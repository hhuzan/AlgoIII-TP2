package facciones;

public interface Faccion {
}

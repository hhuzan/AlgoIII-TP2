package tablero;

import entidades.Entidad;
import facciones.Faccion;
import jugador.Jugador;
import otros.Posicion;

public abstract class  Vacio extends Casillero {

    public Vacio(Posicion posicion) {
        super(posicion);
    }

    /*Métodos principales*/
    public abstract void colocarEntidad(Entidad entidad, Tablero tablero, Jugador jugador);
    public abstract void recibirEntidad(Casillero origen, Entidad entidad, Tablero tablero);

    public void moverEntidad(Casillero destino, Tablero tablero, Jugador jugador){
        //Nunca puede mover entidad
    }
    public void usarHabilidad(Casillero receptor, Tablero tablero, Jugador jugador){
        //Nunca puede usar habilidad
    }

    public void remplazatePorVacio(Tablero tablero){
        //No hace nada
    }

    public void infligirDanio(double power, Entidad emisor, Tablero tablero){
        //no hace nada
    }

    public void infligirCuracion(double power, Entidad emisor, Tablero tablero){
        //no hace nada
    }


}
